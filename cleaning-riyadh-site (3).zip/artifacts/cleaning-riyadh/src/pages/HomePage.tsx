import React, { useState } from 'react';
import { FaWhatsapp, FaPhoneAlt, FaCheck, FaGem, FaArrowLeft, FaBars, FaTimes, FaChevronDown } from 'react-icons/fa';

import heroImg from "@assets/cleaning-images/hero-cleaning.webp";
import villaImg from "@assets/cleaning-images/villa-cleaning.webp";
import apartmentImg from "@assets/cleaning-images/apartment-cleaning.webp";
import deepImg from "@assets/cleaning-images/deep-cleaning.webp";
import sofaImg from "@assets/cleaning-images/sofa-carpet-cleaning.webp";
import constructionImg from "@assets/cleaning-images/post-construction-cleaning.webp";
import recurringImg from "@assets/cleaning-images/recurring-cleaning.webp";
import pestImg from "@assets/cleaning-images/pest-control.jpg";

const PHONE_NUMBER = "0509665092";
const PHONE_LINK = "tel:+966509665092";
const WHATSAPP_LINK = "https://wa.me/966509665092?text=%D9%85%D8%B1%D8%AD%D8%A8%D9%8B%D8%A7%D8%8C%20%D8%A3%D8%B1%D9%8A%D8%AF%20%D8%A7%D9%84%D8%A7%D8%B3%D8%AA%D9%81%D8%B3%D8%A7%D8%B1%20%D8%B9%D9%86%20%D8%AE%D8%AF%D9%85%D8%A7%D8%AA%20%D8%A7%D9%84%D8%AA%D9%86%D8%B8%D9%8A%D9%81%20%D9%88%D9%85%D9%83%D8%A7%D9%81%D8%AD%D8%A9%20%D8%A7%D9%84%D8%AD%D8%B4%D8%B1%D8%A7%D8%AA";

export default function HomePage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const toggleFaq = (index: number) => {
    setActiveFaq(activeFaq === index ? null : index);
  };

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const services = [
    { title: "تنظيف الفلل", desc: "تنظيف شامل للفلل والمجالس والمطابخ والواجهات الداخلية.", img: villaImg },
    { title: "تنظيف الشقق والمنازل", desc: "تنظيف دوري أو لمرة واحدة يشمل الغرف والمرافق بكامل العناية.", img: apartmentImg },
    { title: "تنظيف عميق", desc: "عناية دقيقة بالمطابخ والحمامات والزوايا بمواد متخصصة.", img: deepImg },
    { title: "تنظيف الكنب والسجاد", desc: "غسيل وتعقيم للمفروشات بأجهزة متخصصة مع تجفيف سريع.", img: sofaImg },
    { title: "تنظيف ما بعد التشطيب", desc: "إزالة آثار البناء والغبار وتجهيز الوحدة الجديدة للسكن.", img: constructionImg },
    { title: "تنظيف دوري", desc: "زيارات أسبوعية أو شهرية للحفاظ على نظافة منزلك باستمرار.", img: recurringImg },
    { title: "مكافحة الحشرات", desc: "رش ومكافحة شاملة للحشرات والقوارض بمواد آمنة ومعتمدة.", img: pestImg },
  ];

  const faqs = [
    { q: "هل توفرون مواد وأدوات التنظيف؟", a: "نعم، يصل الفريق مجهزًا بالمعدات ومواد التنظيف اللازمة، ويمكن مراعاة أي طلبات خاصة قبل الموعد." },
    { q: "كيف يتم تحديد السعر؟", a: "يعتمد السعر على نوع الخدمة ومساحة المنزل وحالته. أرسل التفاصيل عبر واتساب لتحصل على تقدير واضح قبل الحجز." },
    { q: "هل تغطون جميع أحياء الرياض؟", a: "نغطي مدينة الرياض وأحياءها، ويتم تأكيد الموعد حسب الحي وتوفر الفريق." },
    { q: "هل يمكن حجز تنظيف دوري؟", a: "نعم، نوفر مواعيد أسبوعية وشهرية مرنة حسب احتياج المنزل." },
    { q: "ما خدمات التنظيف التي توفرونها؟", a: "نوفر تنظيف المنازل والفلل والقصور والمكاتب والشركات والخزانات والواجهات والزجاج والكنب والسجاد، بالإضافة إلى التنظيف العميق وما بعد التشطيب ومكافحة الحشرات." },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground font-sans overflow-x-hidden selection:bg-accent/20">
      {/* Topbar */}
      <div className="bg-muted py-2 px-4 text-sm text-center md:flex md:justify-center md:items-center md:gap-4 border-b border-border/50">
        <span className="text-muted-foreground font-medium">نخدم جميع أحياء الرياض</span>
        <span className="hidden md:inline text-border">•</span>
        <a href={PHONE_LINK} className="font-bold text-foreground hover:text-accent transition-colors flex items-center justify-center gap-2 mt-1 md:mt-0" dir="ltr">
          {PHONE_NUMBER} <FaPhoneAlt className="text-xs" />
        </a>
      </div>

      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-md border-b border-border/50 shadow-sm">
        <div className="container mx-auto px-4 md:px-6 h-20 flex items-center justify-between">
          <a href="#" className="flex items-center gap-2 group">
            <FaGem className="text-accent text-3xl group-hover:rotate-12 transition-transform duration-300" />
            <div className="flex flex-col">
              <span className="font-bold text-xl md:text-2xl leading-none text-primary">لؤلؤة الرياض</span>
              <span className="text-[10px] text-muted-foreground font-bold tracking-widest leading-none mt-1">PEARL OF RIYADH</span>
            </div>
          </a>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8 font-medium">
            <button onClick={() => scrollToSection('services')} className="hover:text-accent transition-colors">خدماتنا</button>
            <button onClick={() => scrollToSection('why-us')} className="hover:text-accent transition-colors">لماذا نحن</button>
            <button onClick={() => scrollToSection('faq')} className="hover:text-accent transition-colors">الأسئلة الشائعة</button>
          </div>

          <div className="hidden md:flex items-center gap-3">
            <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 bg-secondary text-secondary-foreground px-5 py-2.5 rounded-xl font-bold hover:bg-secondary/90 transition-all hover-elevate">
              <FaWhatsapp className="text-xl" />
              واتساب
            </a>
            <a href={PHONE_LINK} className="flex items-center gap-2 bg-primary text-primary-foreground px-5 py-2.5 rounded-xl font-bold hover:bg-primary/90 transition-all hover-elevate">
              <FaPhoneAlt />
              اتصل الآن
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden text-2xl text-primary p-2" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <FaTimes /> : <FaBars />}
          </button>
        </div>

        {/* Mobile Nav */}
        {mobileMenuOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-background border-b border-border p-4 flex flex-col gap-4 shadow-lg animate-in slide-in-from-top-4">
            <button onClick={() => scrollToSection('services')} className="text-right font-bold p-2 border-b border-border/50">خدماتنا</button>
            <button onClick={() => scrollToSection('why-us')} className="text-right font-bold p-2 border-b border-border/50">لماذا نحن</button>
            <button onClick={() => scrollToSection('faq')} className="text-right font-bold p-2 border-b border-border/50">الأسئلة الشائعة</button>
            <div className="flex flex-col gap-3 mt-4">
              <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="flex justify-center items-center gap-2 bg-secondary text-secondary-foreground px-5 py-3 rounded-xl font-bold">
                <FaWhatsapp className="text-xl" /> واتساب
              </a>
              <a href={PHONE_LINK} className="flex justify-center items-center gap-2 bg-primary text-primary-foreground px-5 py-3 rounded-xl font-bold">
                <FaPhoneAlt /> اتصل الآن
              </a>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative pt-12 pb-20 md:pt-20 md:pb-32 overflow-hidden">
        {/* Abstract background shapes */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl -z-10 translate-x-1/2 -translate-y-1/2"></div>
        <div className="absolute bottom-0 left-0 w-[30rem] h-[30rem] bg-secondary/5 rounded-full blur-3xl -z-10 -translate-x-1/2 translate-y-1/2"></div>

        <div className="container mx-auto px-4 md:px-6 flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
          <div className="flex-1 text-center lg:text-right space-y-6 lg:max-w-2xl relative z-10 animate-in fade-in slide-in-from-bottom-8 duration-700">
            <div className="inline-flex items-center gap-2 bg-white/60 border border-accent/20 text-accent font-bold px-4 py-1.5 rounded-full text-sm mb-2 shadow-sm">
              <FaGem className="text-xs" /> خدمات النظافة المتميزة
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-7xl font-black text-primary leading-[1.15]">
              تنظيف منازل وفلل ومكاتب
            </h1>
            <p className="text-2xl md:text-3xl font-bold text-accent">
              بعناية تليق بمكانك
            </p>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-lg mx-auto lg:mx-0">
              فريق رجال مدرب، مواد آمنة، ومواعيد مرنة لتنظيف منزلك أو مكتبك باحترافية في جميع أحياء الرياض.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-4">
              <a href={PHONE_LINK} className="w-full sm:w-auto flex justify-center items-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-2xl font-bold text-lg hover:bg-primary/90 transition-all hover:-translate-y-1 shadow-lg shadow-primary/20">
                <FaPhoneAlt /> اتصل الآن مجانًا
              </a>
              <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto flex justify-center items-center gap-2 bg-secondary text-secondary-foreground px-8 py-4 rounded-2xl font-bold text-lg hover:bg-secondary/90 transition-all hover:-translate-y-1 shadow-lg shadow-secondary/20">
                <FaWhatsapp className="text-2xl" /> اطلب السعر عبر واتساب
              </a>
            </div>

            <div className="flex flex-wrap justify-center lg:justify-start gap-4 md:gap-6 pt-6 text-sm font-semibold text-primary/80">
              <span className="flex items-center gap-1.5"><FaCheck className="text-accent" /> تقدير سعر قبل الحجز</span>
              <span className="flex items-center gap-1.5"><FaCheck className="text-accent" /> استجابة سريعة</span>
              <span className="flex items-center gap-1.5"><FaCheck className="text-accent" /> تغطية الرياض</span>
            </div>
          </div>

          <div className="flex-1 relative w-full max-w-lg lg:max-w-none animate-in fade-in slide-in-from-left-8 duration-1000 delay-200">
            <div className="relative aspect-square md:aspect-[4/3] lg:aspect-square rounded-full md:rounded-[3rem] overflow-hidden border-8 border-white shadow-2xl shadow-primary/10">
              <img src={heroImg} alt="فريق تنظيف محترف" className="w-full h-full object-cover object-center" />
            </div>
            
            {/* Floating Card */}
            <div className="absolute -bottom-6 -left-6 md:-left-12 bg-white p-5 rounded-2xl shadow-xl border border-border flex items-center gap-4 animate-in zoom-in duration-500 delay-700">
              <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center text-accent">
                <FaGem className="text-xl" />
              </div>
              <div>
                <p className="font-bold text-primary">نظافة تلاحظها</p>
                <p className="text-sm font-medium text-muted-foreground">من أول زيارة</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Bar */}
      <section className="bg-muted py-10 border-y border-border/50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-4 divide-y sm:divide-y-0 sm:divide-x sm:divide-x-reverse divide-border/60">
            {[
              { title: "ضمان جودة الخدمة", desc: "نراجع النتيجة قبل المغادرة" },
              { title: "فريق مدرب وموثوق", desc: "عناية وخصوصية في كل زيارة" },
              { title: "مواد تنظيف آمنة", desc: "مناسبة للمنزل والعائلة" },
              { title: "مواعيد مرنة", desc: "نصل في الوقت المتفق عليه" }
            ].map((benefit, i) => (
              <div key={i} className="flex flex-col items-center text-center pt-8 sm:pt-0 px-4 first:pt-0">
                <div className="w-14 h-14 bg-background rounded-full flex items-center justify-center text-accent mb-4 shadow-sm">
                  <FaCheck className="text-xl" />
                </div>
                <h3 className="font-bold text-lg text-primary mb-1">{benefit.title}</h3>
                <p className="text-muted-foreground text-sm font-medium">{benefit.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 md:py-32 relative">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <span className="text-accent font-bold tracking-wider text-sm">جميع خدمات التنظيف</span>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-primary">تنظيف المنازل والفلل والقصور والمكاتب</h2>
            <p className="text-lg text-muted-foreground">اختر الخدمة المناسبة، وأرسل طلبك لتحصل على تقدير سعر واضح.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 lg:gap-8">
            {services.map((service, i) => (
              <div key={i} className="group bg-card border border-card-border rounded-3xl overflow-hidden hover-elevate transition-all duration-300 shadow-sm flex flex-col">
                <div className="aspect-[4/3] overflow-hidden relative">
                  <div className="absolute inset-0 bg-primary/10 group-hover:bg-transparent transition-colors z-10"></div>
                  <img src={service.img} alt={service.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out" />
                </div>
                <div className="p-6 md:p-8 flex flex-col flex-1">
                  <h3 className="text-xl font-bold text-primary mb-3">{service.title}</h3>
                  <p className="text-muted-foreground mb-6 flex-1 leading-relaxed">{service.desc}</p>
                  <a 
                    href={`${WHATSAPP_LINK}%20-%20%D8%A8%D8%AE%D8%B5%D9%88%D8%B5%20${encodeURIComponent(service.title)}`} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="inline-flex items-center justify-between w-full text-accent font-bold hover:text-accent/80 transition-colors group/btn"
                  >
                    اطلب هذه الخدمة
                    <div className="w-10 h-10 rounded-full bg-accent/10 flex items-center justify-center group-hover/btn:bg-accent group-hover/btn:text-white transition-colors">
                      <FaArrowLeft className="transform group-hover/btn:-translate-x-1 transition-transform" />
                    </div>
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Us Section */}
      <section id="why-us" className="py-20 md:py-32 bg-primary text-primary-foreground relative overflow-hidden">
        {/* Abstract bg for dark section */}
        <div className="absolute inset-0 opacity-10">
           <div className="absolute top-0 right-0 w-[40rem] h-[40rem] bg-white rounded-full blur-[100px] -translate-y-1/2 translate-x-1/3"></div>
        </div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="max-w-4xl mx-auto flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
            <div className="flex-1 space-y-8">
              <div className="space-y-4">
                <span className="text-accent font-bold tracking-wider text-sm bg-accent/20 px-3 py-1 rounded-full inline-block">الفرق يظهر في التفاصيل</span>
                <h2 className="text-3xl md:text-4xl lg:text-5xl font-black leading-[1.2]">نظافة حقيقية، وليست مجرد ترتيب سريع</h2>
                <p className="text-lg text-primary-foreground/80 leading-relaxed max-w-xl">
                  نعمل بخطوات واضحة ومعدات مناسبة لكل سطح، مع اهتمام خاص بالتفاصيل التي يصعب الوصول إليها.
                </p>
              </div>

              <ul className="space-y-5">
                {[
                  "تنظيف دقيق للزوايا والأسطح",
                  "مواد مناسبة لنوع الأثاث",
                  "مراجعة النتيجة مع العميل",
                  "سعر واضح قبل بدء الخدمة"
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-4 text-lg font-medium">
                    <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center shrink-0 shadow-lg shadow-accent/20">
                      <FaCheck className="text-white text-sm" />
                    </div>
                    {item}
                  </li>
                ))}
              </ul>

              <div className="pt-4">
                <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-3 bg-white text-primary px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-100 transition-all hover:scale-105">
                  احصل على تقدير السعر الآن <FaArrowLeft />
                </a>
              </div>
            </div>
            
            <div className="flex-1 w-full max-w-lg">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4 mt-8">
                  <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-2xl">
                    <img src={apartmentImg} alt="تنظيف" className="w-full h-full object-cover" />
                  </div>
                  <div className="bg-white/10 backdrop-blur-md p-6 rounded-3xl border border-white/10">
                    <div className="text-3xl font-black text-accent mb-1">+500</div>
                    <div className="text-sm font-medium">عميل راضٍ في الرياض</div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="bg-secondary p-6 rounded-3xl border border-white/10 text-center flex flex-col items-center justify-center">
                    <FaWhatsapp className="text-4xl mb-3 text-white" />
                    <div className="font-bold mb-1">دعم متواصل</div>
                    <div className="text-xs text-white/80">نرد على استفساراتكم فوراً</div>
                  </div>
                  <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-2xl">
                    <img src={deepImg} alt="تنظيف عميق" className="w-full h-full object-cover" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden bg-background">
        <div className="container mx-auto px-4 md:px-6">
          <div className="bg-muted border border-border/60 rounded-[3rem] p-10 md:p-16 lg:p-24 text-center max-w-5xl mx-auto relative overflow-hidden shadow-xl shadow-primary/5">
            {/* Decorative circles */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-accent/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-secondary/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>
            
            <div className="relative z-10 space-y-8 max-w-2xl mx-auto">
              <span className="text-accent font-bold tracking-wider text-sm">احجز الآن</span>
              <h2 className="text-3xl md:text-5xl font-black text-primary leading-tight">اعرف تكلفة تنظيف مكانك خلال دقائق</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                تواصل معنا مباشرة وحدد نوع الخدمة والمساحة والحي لتحصل على السعر والموعد المناسب.
              </p>
              
              <div className="text-3xl md:text-4xl font-black text-primary py-4 tracking-wider" dir="ltr">
                {PHONE_NUMBER}
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <a href={PHONE_LINK} className="w-full sm:w-auto flex justify-center items-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-2xl font-bold text-lg hover:bg-primary/90 transition-all hover:scale-105 shadow-lg">
                  <FaPhoneAlt /> اتصل الآن
                </a>
                <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto flex justify-center items-center gap-2 bg-secondary text-secondary-foreground px-8 py-4 rounded-2xl font-bold text-lg hover:bg-secondary/90 transition-all hover:scale-105 shadow-lg">
                  <FaWhatsapp className="text-2xl" /> اطلب السعر عبر واتساب
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 md:py-32 bg-background border-t border-border/50">
        <div className="container mx-auto px-4 md:px-6 max-w-3xl">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-3xl md:text-4xl font-black text-primary">الأسئلة الشائعة</h2>
            <p className="text-lg text-muted-foreground">كل ما تحتاج معرفته عن خدماتنا</p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, i) => (
              <div key={i} className="bg-card border border-card-border rounded-2xl overflow-hidden transition-all duration-300">
                <button 
                  onClick={() => toggleFaq(i)}
                  className="w-full text-right px-6 py-5 flex items-center justify-between font-bold text-lg hover:bg-muted/50 transition-colors"
                >
                  <span className="text-primary pr-4">{faq.q}</span>
                  <div className={`w-8 h-8 rounded-full bg-muted flex items-center justify-center text-primary transition-transform duration-300 ${activeFaq === i ? 'rotate-180' : ''}`}>
                    <FaChevronDown className="text-sm" />
                  </div>
                </button>
                <div 
                  className={`px-6 overflow-hidden transition-all duration-300 ease-in-out ${activeFaq === i ? 'max-h-40 py-5 border-t border-border/50' : 'max-h-0 py-0'}`}
                >
                  <p className="text-muted-foreground font-medium leading-relaxed">{faq.a}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted py-12 md:py-16 border-t border-border/50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8 md:gap-12 text-center md:text-right">
            
            <div className="flex-1 space-y-6 max-w-md">
              <a href="#" className="flex items-center gap-2 group justify-center md:justify-start">
                <FaGem className="text-accent text-3xl group-hover:rotate-12 transition-transform duration-300" />
                <div className="flex flex-col">
                  <span className="font-bold text-2xl leading-none text-primary">لؤلؤة الرياض</span>
                  <span className="text-[10px] text-muted-foreground font-bold tracking-widest leading-none mt-1">PEARL OF RIYADH</span>
                </div>
              </a>
              <p className="text-sm text-muted-foreground leading-relaxed font-medium">
                سياسة الخصوصية: لا يجمع الموقع بيانات تسجيل. عند الضغط على واتساب تنتقل المحادثة إلى خدمة واتساب وتخضع لسياساتها، ويمكنك التواصل معنا مباشرة عبر الرقم الموضح في الموقع.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-2 bg-secondary/10 text-secondary border border-secondary/20 px-6 py-3 rounded-xl font-bold hover:bg-secondary hover:text-white transition-all">
                <FaWhatsapp className="text-xl" />
                تواصل عبر واتساب
              </a>
              <a href={PHONE_LINK} className="flex items-center justify-center gap-2 bg-primary/10 text-primary border border-primary/20 px-6 py-3 rounded-xl font-bold hover:bg-primary hover:text-white transition-all">
                <FaPhoneAlt />
                {PHONE_NUMBER}
              </a>
            </div>

          </div>
          
          <div className="mt-12 pt-8 border-t border-border/50 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground font-medium">
            <p>جميع الحقوق محفوظة © {new Date().getFullYear()} لؤلؤة الرياض للتنظيف.</p>
            <p>تصميم وتطوير بكل <FaGem className="inline text-accent mx-1 text-xs" /> لخدمتكم.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
